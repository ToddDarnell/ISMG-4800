<?php
if(!isset($oid)) 
{ $oid = 8; 
  if(isset($_REQUEST["oid"])) $oid = $_REQUEST["oid"];
  $solo=true; 
}

require("includes/db.inc");

$qry = "Select * from Orders Where OrderID=" . $oid . ";";   
$rs = mysql_query($qry)
    or die('Query1 failed: ' . mysql_error() . '<br>');

// only one item in ResultSet use ?_fetch_array() to move to it
$row   = mysql_fetch_array($rs);
$ship  = $row["Ship"];
$total = $row["Total"];
   
$to      = $row["Email"];
$from    = "orders@outdoordepot.com";
$subject = "Outdoor Depot - Order Confirmation (OrderID: $oid)";

// To send HTML mail, the Content-type header must be set
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

// Additional headers
//$headers .= 'To: Mary <mary@example.com>, Kelly <kelly@example.com>' . "\r\n";
$headers .= "From: $from" . "\r\n";


$message = 
"<html>
<head>
  <title>Order Confirmation Outdoor Depot</title>
  <style>
    h3 { color: green; text-decoration: underline overline;}
    th { background-color: #FFFFCC; color: darkgreen; }
  </style>
</head>
<body>
<p>Dear " . $row['CName'] . ",
<p>Thank you for shopping at Outdoor Depot!
<p>Your order number $oid has been received and is being processed. We will send you a confirmation e-mail when your order ships. Your credit card will not be billed until your order is shipped.
<p>Below are your order details. If you have any questions about your order, please call us at 1-800-555-1212 or e-mail sales@OutdoorDepot.com.

<h3>CUSTOMER INFORMATION / BILLING INFORMATION</h3>
<p>"  . $row['CName'] . "
<br>" . $row['Address'] . "
<br>" . $row['City'] . ", " . $row['State'] . " " . $row['PostalCode'] . "
<br>" . $row['Country'] . "

<p><b>Paid by:</b> Credit Card: " . $row['PaymentMethod'] . "
<br><b>Credit Card Number:</b> XXXX-XXXX-XXXX-" . substr($row['PaymentNumber'], 12, 4) . "
<br><b>Credit Card Expiration Date:</b> " . $row['ExpDate'] . "

<h3>ORDER INFORMATION</h3>
<p>OutdoorDepot.com
<br><b>Order number:</b> $oid
<br><b>Order Date:</b> " . $row['OrderDate'] . "</p>
<table border=0>
<tr><th>Product</th><th>Size</th><th>Color</th>
    <th>Price</th><th>Quantity</th><th>Total Price</th></tr>";

  $qry = "Select * from OrderDetails Where OrderID=" . $oid . ";";
  $rs = mysql_query($qry)
      or die('Query2 failed: ' . mysql_error() . '<br>');
  $stotal = 0; 
  while($row = mysql_fetch_array($rs))
  {
    $itotal = (float)$row['Price']*(int)$row['Quantity'];
    $stotal += $itotal;
    $message .= "<tr>
    <td>" . $row['Product'] . "</td>
    <td align=center>" . $row['ItemSize'] . "</td>
    <td align=center>" . $row['Color'] . "</td>
    <td align=right>$" . $row['Price'] . "</td>
    <td align=center>" . $row['Quantity'] . "</td>
    <td align=right>$$itotal</td></tr>";  
  }
  $message .= "<tr><td colspan=5 align=right>Subtotal:</td>
     <td align=right>$$itotal</td></tr>
 <tr><td colspan=5 align=right>Shipping:</td>
     <td align=right>$$ship</td></tr>
 <tr><td colspan=5 align=right>Total Order:</td>
     <td align=right>$$total</td></tr></table>

<h3>SHIPPING INFORMATION</h3>
<p>A shipping tracking number will be sent with your shipping confirmation e-mail.
<p>Unless otherwise specified or requested, all orders are shipped via UPS Ground. Express delivery is available for an additional charge. Please contact us immediately if you require expedited shipping. We will notify you of any additional costs before your order ships.

<h3>SATISFACTION GUARANTEED</h3>
<p>We stand behind the products we sell. If for any reason you are not satisfied with your purchase you may return it within 21 (twenty-one) days of receipt of order.
<p>Once again, thank you for shopping at Outdoor Depot!
<p>Outdoor Depot Online Sales<br>sales@OutdoorDepot.com<br>1-800-555-1212";

if(mail($to, $subject, $message, $headers) && $solo=true)
{
  echo "<p>The following confirmation message has been successfully sent:</p>" ;
  echo "To: $to<br>From: $from<br>Subject: $subject<br>$message";
} else {
  echo "<p>The following confirmation message delivery failed...</p>" ;
  echo "To: $to<br>From: $from<br>Subject: $subject<br>$message";
}

?>