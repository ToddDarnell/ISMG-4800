<HTML>
<HEAD>
<TITLE>Outdoor Depot: Check-Out</TITLE>
<link rel="stylesheet" type="text/css" href="od.css">
<script LANGUAGE="JavaScript" SRC="scripts/odcart.js"></script>
<script LANGUAGE="JavaScript" SRC="scripts/validate.js"></script>
</HEAD>
<BODY>
<?php require("includes/header.inc"); ?>
<?php require("includes/lmenu.inc"); ?>

<form method="post" name="purchaseform" action="checkout2.php" onsubmit="return checkform(this);">
<table width=100% cellpadding="0" cellspacing="0">
  <tr>
    <td width="284">
      <h4 class=darkt>Step 1: Fill In Your Address Information</h4>
    </td>
    <td>
      <hr color="#005000">
    </td>
  </tr>
</table>

<table border='0' cellspacing='0' cellpadding='0'>
<TR>
  <TD><B>Name</B>&nbsp;</TD>
  <TD><INPUT type="text" name="CName" value="" maxlength=30 size="33"></TD>
</TR>
<TR>
  <TD><B>Address</B></TD>
  <TD><INPUT type="text" name="Address" value="" maxlength=30 size="33"></TD>
</TR>
<TR>
  <TD><B>City/Town</B>&nbsp;</TD>
  <TD><INPUT type="text" name="City" value="" size="33" > </TD>
</TR>
<TR> 
  <TD><B>State/Province</B>&nbsp;</TD>
  <TD><INPUT type="text" name="State" value="" size="10" ></TD>
</TR>
<TR>
  <TD><B>ZIP/Postal Code</B></TD>
  <TD><INPUT size=10 type="text" name="Postcode" value="" ></TD>
</TR>
<TR>
  <TD><B>Country</B>&nbsp;</td>
  <td colspan=3><SELECT NAME="Country" SIZE=1>
                <OPTION SELECTED VALUE="US">United States</OPTION>
                <OPTION VALUE="AF">Afghanistan</OPTION>
                <OPTION VALUE="AL">Albania</OPTION>
                <OPTION VALUE="DZ">Algeria</OPTION>
                <OPTION VALUE="AS">American Samoa</OPTION>
                <OPTION VALUE="AD">Andorra</OPTION>
                <OPTION VALUE="AO">Angola</OPTION>
                <OPTION VALUE="AI">Anguilla</OPTION>
                <OPTION VALUE="AQ">Antarctica</OPTION>
                <OPTION VALUE="AG">Antigua and Barbuda</OPTION>
                <OPTION VALUE="AR">Argentina</OPTION>
                <OPTION VALUE="AM">Armenia</OPTION>
                <OPTION VALUE="AW">Aruba</OPTION>
                <OPTION VALUE="AU">Australia</OPTION>
                <OPTION VALUE="AT">Austria</OPTION>
                <OPTION VALUE="AZ">Azerbaijan</OPTION>
                <OPTION VALUE="BS">Bahamas</OPTION>
                <OPTION VALUE="BH">Bahrain</OPTION>
                <OPTION VALUE="BD">Bangladesh</OPTION>
                <OPTION VALUE="BB">Barbados</OPTION>
                <OPTION VALUE="BY">Belarus</OPTION>
                <OPTION VALUE="BE">Belgium</OPTION>
                <OPTION VALUE="BZ">Belize</OPTION>
                <OPTION VALUE="BJ">Benin</OPTION>
                <OPTION VALUE="BM">Bermuda</OPTION>
                <OPTION VALUE="BT">Bhutan</OPTION>
                <OPTION VALUE="BO">Bolivia</OPTION>
                <OPTION VALUE="BA">Bosnia and Herzegovina</OPTION>
                <OPTION VALUE="BW">Botswana</OPTION>
                <OPTION VALUE="BV">Bouvet Island</OPTION>
                <OPTION VALUE="BR">Brazil</OPTION>
                <OPTION VALUE="IO">British Indian Ocean Territory</OPTION>
                <OPTION VALUE="BN">Brunei</OPTION>
                <OPTION VALUE="BG">Bulgaria</OPTION>
                <OPTION VALUE="BF">Burkina Faso</OPTION>
                <OPTION VALUE="BI">Burundi</OPTION>
                <OPTION VALUE="KH">Cambodia</OPTION>
                <OPTION VALUE="CM">Cameroon</OPTION>
                <OPTION VALUE="CA">Canada</OPTION>
                <OPTION VALUE="CV">Cape Verde</OPTION>
                <OPTION VALUE="KY">Cayman Islands</OPTION>
                <OPTION VALUE="CF">Central African Republic</OPTION>
                <OPTION VALUE="TD">Chad</OPTION>
                <OPTION VALUE="CL">Chile</OPTION>
                <OPTION VALUE="CN">China</OPTION>
                <OPTION VALUE="CX">Christmas Island</OPTION>
                <OPTION VALUE="CC">Cocos Islands</OPTION>
                <OPTION VALUE="CO">Colombia</OPTION>
                <OPTION VALUE="KM">Comoros</OPTION>
                <OPTION VALUE="CG">Congo</OPTION>
                <OPTION VALUE="CK">Cook Islands</OPTION>
                <OPTION VALUE="CR">Costa Rica</OPTION>
                <OPTION VALUE="CI">Cote d'Ivoire</OPTION>
                <OPTION VALUE="HR">Croatia (local name: Hrvatska)</OPTION>
                <OPTION VALUE="CU">Cuba</OPTION>
                <OPTION VALUE="CY">Cyprus</OPTION>
                <OPTION VALUE="CZ">Czech Republic</OPTION><OPTION VALUE="DK">Denmark</OPTION>
                <OPTION VALUE="DJ">Djibouti</OPTION><OPTION VALUE="DM">Dominica</OPTION>
                <OPTION VALUE="DO">Dominican Republic</OPTION>
                <OPTION VALUE="TP">East Timor</OPTION><OPTION VALUE="EC">Ecuador</OPTION>
                <OPTION VALUE="EG">Egypt</OPTION><OPTION VALUE="SV">El Salvador</OPTION>
                <OPTION VALUE="GQ">Equatorial Guinea</OPTION><OPTION VALUE="ER">Eritrea</OPTION>
                <OPTION VALUE="EE">Estonia</OPTION><OPTION VALUE="ET">Ethiopia</OPTION>
                <OPTION VALUE="FK">Falkland Islands (Malvinas)</OPTION>
                <OPTION VALUE="FO">Faroe Islands</OPTION><OPTION VALUE="FJ">Fiji</OPTION>
                <OPTION VALUE="FI">Finland</OPTION><OPTION VALUE="FR">France</OPTION>
                <OPTION VALUE="FX">Metropolitan France</OPTION>
                <OPTION VALUE="GF">French Guiana</OPTION>
                <OPTION VALUE="PF">French Polynesia</OPTION>
                <OPTION VALUE="TF">French Southern Territories</OPTION>
                <OPTION VALUE="GA">Gabon</OPTION><OPTION VALUE="GM">Gambia</OPTION>
                <OPTION VALUE="GE">Georgia</OPTION><OPTION VALUE="DE">Germany</OPTION>
                <OPTION VALUE="GH">Ghana</OPTION><OPTION VALUE="GI">Gibraltar</OPTION>
                <OPTION VALUE="GR">Greece</OPTION><OPTION VALUE="GL">Greenland</OPTION>
                <OPTION VALUE="GD">Grenada</OPTION><OPTION VALUE="GP">Guadeloupe</OPTION>
                <OPTION VALUE="GU">Guam</OPTION><OPTION VALUE="GT">Guatemala</OPTION>
                <OPTION VALUE="GN">Guinea</OPTION><OPTION VALUE="GW">Guinea-Bissau</OPTION>
                <OPTION VALUE="GY">Guyana</OPTION><OPTION VALUE="HT">Haiti</OPTION>
                <OPTION VALUE="HM">Heard and McDonald Islands</OPTION>
                <OPTION VALUE="HN">Honduras</OPTION><OPTION VALUE="HK">Hong Kong</OPTION>
                <OPTION VALUE="HU">Hungary</OPTION><OPTION VALUE="IS">Iceland</OPTION>
                <OPTION VALUE="IN">India</OPTION><OPTION VALUE="ID">Indonesia</OPTION>
                <OPTION VALUE="IR">Iran (Islamic Republic of)</OPTION>
                <OPTION VALUE="IQ">Iraq</OPTION><OPTION VALUE="IE">Ireland</OPTION>
                <OPTION VALUE="IL">Israel</OPTION><OPTION VALUE="IT">Italy</OPTION>
                <OPTION VALUE="JM">Jamaica</OPTION><OPTION VALUE="JP">Japan</OPTION>
                <OPTION VALUE="JO">Jordan</OPTION><OPTION VALUE="KZ">Kazakhstan</OPTION>
                <OPTION VALUE="KE">Kenya</OPTION><OPTION VALUE="KI">Kiribati</OPTION>
                <OPTION VALUE="KP">Korea</OPTION><OPTION VALUE="KR">Korea, Republic of</OPTION>
                <OPTION VALUE="KW">Kuwait</OPTION><OPTION VALUE="KG">Kyrgyzstan</OPTION>
                <OPTION VALUE="LA">Lao People's Democratic Republic</OPTION>
                <OPTION VALUE="LV">Latvia</OPTION><OPTION VALUE="LB">Lebanon</OPTION>
                <OPTION VALUE="LS">Lesotho</OPTION><OPTION VALUE="LR">Liberia</OPTION>
                <OPTION VALUE="LY">Libyan Arab Jamahiriya</OPTION>
                <OPTION VALUE="LI">Liechtenstein</OPTION>
                <OPTION VALUE="LT">Lithuania</OPTION>
                <OPTION VALUE="LU">Luxembourg</OPTION>
                <OPTION VALUE="MO">Macau</OPTION><OPTION VALUE="MK">Macedonia</OPTION>
                <OPTION VALUE="MG">Madagascar</OPTION><OPTION VALUE="MW">Malawi</OPTION>
                <OPTION VALUE="MY">Malaysia</OPTION><OPTION VALUE="MV">Maldives</OPTION>
                <OPTION VALUE="ML">Mali</OPTION><OPTION VALUE="MT">Malta</OPTION>
                <OPTION VALUE="MH">Marshall Islands</OPTION>
                <OPTION VALUE="MQ">Martinique</OPTION><OPTION VALUE="MR">Mauritania</OPTION>
                <OPTION VALUE="MU">Mauritius</OPTION><OPTION VALUE="YT">Mayotte</OPTION>
                <OPTION VALUE="MX">Mexico</OPTION>
                <OPTION VALUE="FM">Micronesia, Federated States of</OPTION>
                <OPTION VALUE="MD">Moldova, Republic of</OPTION>
                <OPTION VALUE="MC">Monaco</OPTION><OPTION VALUE="MN">Mongolia</OPTION>
                <OPTION VALUE="MS">Montserrat</OPTION><OPTION VALUE="MA">Morocco</OPTION>
                <OPTION VALUE="MZ">Mozambique</OPTION><OPTION VALUE="MM">Myanmar</OPTION>
                <OPTION VALUE="NA">Namibia</OPTION><OPTION VALUE="NR">Nauru</OPTION>
                <OPTION VALUE="NP">Nepal</OPTION><OPTION VALUE="AN">Netherlands Antilles</OPTION>
                <OPTION VALUE="NL">The Netherlands</OPTION>
                <OPTION VALUE="NC">New Caledonia</OPTION>
                <OPTION VALUE="NZ">New Zealand</OPTION><OPTION VALUE="NI">Nicaragua</OPTION>
                <OPTION VALUE="NE">Niger</OPTION><OPTION VALUE="NG">Nigeria</OPTION><OPTION VALUE="NU">Niue</OPTION>
                <OPTION VALUE="NF">Norfolk Island</OPTION>
                <OPTION VALUE="MP">Northern Mariana Islands</OPTION><OPTION VALUE="NO">Norway</OPTION><OPTION VALUE="OM">Oman</OPTION><OPTION VALUE="PK">Pakistan</OPTION>
                <OPTION VALUE="PW">Palau</OPTION><OPTION VALUE="PA">Panama</OPTION>
                <OPTION VALUE="PG">Papua New Guinea</OPTION><OPTION VALUE="PY">Paraguay</OPTION><OPTION VALUE="PE">Peru</OPTION><OPTION VALUE="PH">Philippines</OPTION><OPTION VALUE="PN">Pitcairn</OPTION>
                <OPTION VALUE="PL">Poland</OPTION><OPTION VALUE="PT">Portugal</OPTION>
                <OPTION VALUE="PR">Puerto Rico</OPTION><OPTION VALUE="QA">Qatar</OPTION><OPTION VALUE="RE">Reunion</OPTION>
                <OPTION VALUE="RO">Romania</OPTION><OPTION VALUE="RU">Russian Federation</OPTION><OPTION VALUE="RW">Rwanda</OPTION><OPTION VALUE="KN">Saint Kitts and Nevis</OPTION>
                <OPTION VALUE="LC">Saint Lucia</OPTION><OPTION VALUE="VC">Saint Vincent and the Grenadines</OPTION><OPTION VALUE="WS">Samoa</OPTION><OPTION VALUE="SM">San Marino</OPTION>
                <OPTION VALUE="ST">Sao Tome and Principe</OPTION><OPTION VALUE="SA">Saudi Arabia</OPTION><OPTION VALUE="SN">Senegal</OPTION><OPTION VALUE="SC">Seychelles</OPTION><OPTION VALUE="SL">Sierra Leone</OPTION><OPTION VALUE="SG">Singapore</OPTION>
                <OPTION VALUE="SK">Slovakia (Slovak Republic)</OPTION><OPTION VALUE="SI">Slovenia</OPTION><OPTION VALUE="SB">Solomon Islands</OPTION><OPTION VALUE="SO">Somalia</OPTION><OPTION VALUE="ZA">South Africa</OPTION><OPTION VALUE="ES">Spain</OPTION><OPTION VALUE="LK">Sri Lanka</OPTION>
                <OPTION VALUE="SH">St. Helena</OPTION><OPTION VALUE="PM">St. Pierre and Miquelon</OPTION><OPTION VALUE="SD">Sudan</OPTION>
                <OPTION VALUE="SR">Suriname</OPTION><OPTION VALUE="SJ">Svalbard and Jan Mayen Islands</OPTION><OPTION VALUE="SZ">Swaziland</OPTION><OPTION VALUE="SE">Sweden</OPTION><OPTION VALUE="CH">Switzerland</OPTION><OPTION VALUE="SY">Syrian Arab Republic</OPTION><OPTION VALUE="TW">Taiwan</OPTION><OPTION VALUE="TJ">Tajikistan</OPTION>
                <OPTION VALUE="TZ">Tanzania, United Republic of</OPTION><OPTION VALUE="TH">Thailand</OPTION><OPTION VALUE="TG">Togo</OPTION><OPTION VALUE="TK">Tokelau</OPTION><OPTION VALUE="TO">Tonga</OPTION><OPTION VALUE="TT">Trinidad and Tobago</OPTION><OPTION VALUE="TN">Tunisia</OPTION><OPTION VALUE="TR">Turkey</OPTION>
                <OPTION VALUE="TM">Turkmenistan</OPTION><OPTION VALUE="TC">Turks and Caicos Islands</OPTION><OPTION VALUE="TV">Tuvalu</OPTION><OPTION VALUE="UG">Uganda</OPTION><OPTION VALUE="UA">Ukraine</OPTION>
                <OPTION VALUE="AE">United Arab Emirates</OPTION><OPTION VALUE="GB">United Kingdom</OPTION>
                <OPTION VALUE="US">United States</OPTION><OPTION VALUE="UM">United States Minor Outlying Islands</OPTION><OPTION VALUE="UY">Uruguay</OPTION><OPTION VALUE="UZ">Uzbekistan</OPTION><OPTION VALUE="VU">Vanuatu</OPTION>
                <OPTION VALUE="VA">Vatican City State (Holy See)</OPTION><OPTION VALUE="VE">Venezuela</OPTION><OPTION VALUE="VN">Vietnam</OPTION><OPTION VALUE="VG">Virgin Islands (British)</OPTION><OPTION VALUE="VI">Virgin Islands (U.S.)</OPTION><OPTION VALUE="WF">Wallis And Futuna Islands</OPTION><OPTION VALUE="EH">Western Sahara</OPTION>
                <OPTION VALUE="YE">Yemen</OPTION><OPTION VALUE="YU">Yugoslavia</OPTION><OPTION VALUE="ZR">Zaire</OPTION><OPTION VALUE="ZM">Zambia</OPTION><OPTION VALUE="ZW">Zimbabwe</OPTION>
            </SELECT>
  </TD>
</TR>
<TR>
  <TD><B>Phone</B>&nbsp;</TD>
  <TD><INPUT type="text" name="Phone" value="" size="20" > </TD>
</TR>
<TR>
  <TD><B>E-mail</B>&nbsp;</TD>
  <TD><INPUT type="text" name="Email" value="" size="20" > </TD>
</TR>
</TABLE>
<br>
<table width="100%">
  <tr>
    <td width="284">
      <h4 class=darkt>Step 2: Provide Your Billing Information</h4>
    </td>
    <td>
      <hr color="#005000">
    </td>
  </tr>
</table>

<TABLE border=0 >
<tr><td align=left valign=top>
     <b>Payment method: </b></td><td>
     <SELECT NAME="CreditCard" SIZE=1>
          <OPTION VALUE="MasterCard">Master Card</OPTION>
          <OPTION VALUE="Visa">Visa</OPTION>
          <OPTION VALUE="AmericanExp">American Express</OPTION>
          <OPTION VALUE="Discover">Discover</OPTION>
     </SELECT></td>
</tr>
<tr><td><b>Payment card number:</b> </td>
     <td><INPUT type="password" NAME="CCN" VALUE="" SIZE=20 MAXLENGTH=20></td></tr>
<tr><td>Expiration date</td>
     <td>Month <SELECT NAME="CCExpMM" SIZE=0>
          <OPTION SELECTED VALUE="06">06</OPTION>
          <OPTION VALUE="01">01</OPTION>
          <OPTION VALUE="02">02</OPTION>
          <OPTION VALUE="03">03</OPTION>
          <OPTION VALUE="04">04</OPTION>
          <OPTION VALUE="05">05</OPTION>
          <OPTION VALUE="06">06</OPTION>
          <OPTION VALUE="07">07</OPTION>
          <OPTION VALUE="08">08</OPTION>
          <OPTION VALUE="09">09</OPTION>
          <OPTION VALUE="11">11</OPTION>
          <OPTION VALUE="12">12</OPTION>
       </SELECT>
       Year <SELECT NAME="CCExpYY" SIZE=0>
               <OPTION SELECTED VALUE="2008">2008</OPTION>
               <OPTION VALUE="2006">2006</OPTION>
               <OPTION VALUE="2007">2007</OPTION>
               <OPTION VALUE="2008">2008</OPTION>
               <OPTION VALUE="2009">2009</OPTION>
               <OPTION VALUE="2010">2010</OPTION>
               <OPTION VALUE="2011">2011</OPTION>
               <OPTION VALUE="2012">2012</OPTION>
               <OPTION VALUE="2013">2013</OPTION>
               <OPTION VALUE="2014">2014</OPTION>
               <OPTION VALUE="2015">2015</OPTION>
               <OPTION VALUE="2016">2016</OPTION>
               <OPTION VALUE="2017">2017</OPTION>
               <OPTION VALUE="2018">2018</OPTION>
               <OPTION VALUE="2019">2019</OPTION>
               <OPTION VALUE="2020">2020</OPTION>
               <OPTION VALUE="2021">2021</OPTION>
               <OPTION VALUE="2022">2022</OPTION>
               <OPTION VALUE="2023">2023</OPTION>
               <OPTION VALUE="2024">2024</OPTION>
               <OPTION VALUE="2025">2025</OPTION>
            </SELECT></td> </tr>
</table>
<br>
<table width="100%">
  <tr>
    <td width="284">
      <h4 class=darkt>Step 3: Verify Your Order</h4>
    </td>
    <td>
      <hr color="#005000">
    </td>
  </tr>
</table>

<SCRIPT Language = "JavaScript">
<!--
var head = '<table class="bg1" style="font-size: .917em;" cellpadding=2><tr class="bg2"><th>Product</th><th>Size</th><th>Color</th><th>Price</th><th>Quantity</th><th>Total Price</th></tr>';
writeCart('odCart', 2, 'cartform', '|', 5, head, 'checkout.html'  );
// End -->
</SCRIPT><br>

<input type=submit value="Complete Order">
</form>

<?php require("includes/rmenu.inc"); ?>
<?php require("includes/footer.inc"); ?>